import {Router} from "express"
import ProductManager from "../managers/ProductManager.js"

const productManager = new ProductManager("./src/storages/products.json")
const router = Router()

router.get("/", async (req,res) => {
  try {
    const products = await productManager.getProducts(req.query.limit)
    res.send(products)
  }
  catch(e) {
    res.status(500).send("Error en el servidor")
  }
})

router.get("/:pid", async (req,res) => {
  try {   
    const {pid} = req.params
    const product = await productManager.getProductById(parseInt(pid))
    res.status(product == "No existe" ? 404 : 200).send(product)
  }
  catch(e) {
    res.status(500).send("Error en el servidor")
  }
})

router.post("/", async (req,res) => {
  try {
    const newProduct = await productManager.addProduct(req.body)
    res.status(!newProduct || newProduct == "Invalid code" || newProduct == "Missed properties" ? 400 : 200).send(newProduct)
  }
  catch(e) {
    res.status(500).send("Error en el servidor")
  }
})

router.put("/:pid", async (req,res) => {
  try {
    const {pid} = req.params
    const updatedProducts = await productManager.updateProduct(parseInt(pid),req.body)
    res.status(updatedProducts == "Invalid property" ? 400 : 200).send(updatedProducts)
  }
  catch(e) {
    res.status(500).send("Error en el servidor")
  }
})

router.delete("/:pid", async (req,res) => {
  try {
    const {pid} = req.params
    const deletedProduct = await productManager.deleteProduct(parseInt(pid))
    res.status(deletedProduct == "No existe" ? 404 : 200).send(deletedProduct)
  }
  catch(e) {
    res.status(500).send("Error en el servidor")
  }
})

export default router