import {Router} from "express"
import CartManager from "../managers/CartManager.js"

const cartManager = new CartManager("./src/storages/carts.json")
const router = Router()

router.get("/:cid", async (req,res) => {
  try {
    const {cid} = req.params
    const products = await cartManager.getProductsOfCart(parseInt(cid))
    res.status(products == "No existe" ? 400 : 200).send(products)
  }
  catch(e) {
    res.status(500).send("Error en el servidor")
  }
})

router.post("/", async (req,res) => {
  try {
    const cart = await cartManager.addCart(req.body.products || [])
    res.status(!cart || cart == "Missed properties" ? 400 : 200).send(cart)
  }
  catch(e) {
    res.status(500).send("Error en el servidor")
  }
})

router.post("/:cid/product/:pid", async (req,res) => {
  try {
    const {params: {cid,pid}, body: {quantity}} = req 
    if (isNaN(cid) || isNaN(pid) || (isNaN(quantity) && typeof quantity != undefined)) return res.status(400).send("Invalid parameters or body")
    const newProducts = await cartManager.addProductsInCart(parseInt(cid),parseInt(pid),quantity || 1)
    res.status(!newProducts ? 400 : 200).send(newProducts)
  }
  catch(e) {
    res.status(500).send("Error en el servidor")
  }
})

export default router